# AIによる自然言語指示型ロボット操作(Physical AI講座 2026 応用編1 最終課題)

日本語の自然言語指示をAIが解釈してJSON動作命令に変換し、ロボットを制御するシステムです。
さらに **A\*経路計画AI** による障害物回避ナビゲーションも備えています。

**すべて無料・ローカル実行**(有料API・APIキー不要)。ROS 2の `/cmd_vel`(geometry_msgs/Twist)と同じ `v`(並進速度[m/s])・`w`(角速度[rad/s])の速度指令モデルを採用しています。

## 動作環境

- Python 3.10以上
- 依存: `numpy`, `matplotlib`, `pillow`(動画生成時は `ffmpeg` も使用)

```bash
pip install -r requirements.txt
```

## 実行方法

### 1. テストスイート(日本語解析・安全レイヤ・動作・ナビゲーション評価)

```bash
python3 src/test_suite.py
```

結果は `test_results.md` / `test_results.json` に出力されます。

### 2. デモ動画の生成(実際のシミュレーション実行→フレーム→MP4)

```bash
python3 src/run_demo.py
ffmpeg -y -framerate 10 -i video_frames/f%05d.png -c:v libx264 \
       -pix_fmt yuv420p -crf 22 -movflags +faststart pai_final_demo.mp4
```

### 3. 対話型デモ(1命令ずつ実行)

```bash
python3 src/interactive_demo.py
```

## システム構成

```
日本語の指示(「2秒間前進してください」)
  ↓ AI解析 (japanese_parser.py)
{"action": "forward", "duration": 2.0}
  ↓ 安全レイヤ検証 (safety.py)  ← 許可されたactionのみ・duration上限5秒
  ↓ 制御 (robot_sim.py / interactive_demo.py)
ロボットが実行
```

### ファイル構成

| ファイル | 役割 |
|---|---|
| `src/robot_sim.py` | 2D差動駆動ロボットの最小シミュレータ(v,w指令・衝突判定) |
| `src/japanese_parser.py` | 日本語自然言語 → JSON動作命令の変換(ローカルAI・無料) |
| `src/safety.py` | AI出力のホワイトリスト検証(不正JSON・未知action・過大durationで停止) |
| `src/astar_navigator.py` | A\*経路計画による障害物回避ナビゲーションAI |
| `src/q_learning.py` / `src/train_navigator.py` | Q学習(強化学習)の実験コード(参考・未完成) |
| `src/test_suite.py` | テストスイート(実際に実行して結果を記録) |
| `src/run_demo.py` | デモ動画フレームの生成(実際の実行結果のみを描画) |
| `src/interactive_demo.py` | 対話型デモ |

## 許可される動作命令(ホワイトリスト)

`forward` / `backward` / `turn_left` / `turn_right` / `stop` / `auto_navigate`

## 安全設計

- **AIの出力はJSONのみ**。JSONとして解釈できない場合は実行せず停止
- **actionはホワイトリスト6種のみ**。未知のactionは実行せず停止
- **duration上限5.0秒**。異常に長い時間・負の値・非数値は停止
- **衝突を検出したら即停止**
- 「危険」「やめて」「実行不能」等を含む指示はAIが判断して停止
- 速度はコード内で上限管理(MAX_V=0.5 m/s / MAX_W=1.2 rad/s)

## テスト結果(実際の実行記録)

詳細は `test_results.md` を参照。主要な結果:

- 日本語解析テスト: **10/10 成功**
- 安全レイヤテスト(不正JSON・未知action・過大duration等): **8/8 成功**
- 動作テスト(シミュレータで実際に実行・計測): **3/3 成功**
- A\*ナビゲーション評価(ランダム開始位置20回): **ゴール到達率100%**

## 参考: Q学習(強化学習)の実験について

Q学習でもナビゲーションを試みましたが(25,000エピソード訓練)、貪欲方策のゴール到達が安定せず(最高8/10)。
**実際に確認できたこと**:訓練中のゴール到達率は最終チャンクで54%まで上昇。
**判断**:デモでは信頼性の高いA\*経路計画を採用し、Q学習コードは改善課題として残しています。

## ROS 2 / Gazebo への移植について

本リポジトリは講座規則で認められた「Gazebo以外のツール」を使用した軽量2Dシミュレーションです。
`japanese_parser.py` と `safety.py` はROS 2環境でもそのまま利用可能です(ROS 2側は `/cmd_vel` に `Twist` をpublishするだけです)。※本環境ではROS 2の動作確認を実施していないため、**ROS 2上での動作は未確認**です。

## 安全上の注意

- APIキー・パスワード・個人情報は本リポジトリに含まれていません
- 実機で動かす場合は、必ず速度上限を実際のロボットに合わせて再設定してください

## ライセンス

MIT License(詳しくは [LICENSE](LICENSE) を参照)